Computer-Vision-Library sample code.
Performs grayscale conversion and edge detection using OpenCV.
